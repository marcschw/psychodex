"""
Report-Generator: liest cache.json, baut report.html mit:
  1. Kalender-Grid (akt. + nächster Monat) mit Verfügbarkeit + Bekanntschaft
  2. Personen-Stats (wie oft Dienst, mit wem ich wie oft)
  3. INT-Desk + DEU-A Bekanntschaftsübersicht
"""

from __future__ import annotations
import json
import calendar
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path
from html import escape

CACHE_FILE = Path(__file__).parent / "cache.json"
PEOPLE_FILE = Path(__file__).parent / "people.json"
FAVORITES_FILE = Path(__file__).parent / "favorites.txt"
SHITLIST_FILE = Path(__file__).parent / "shitlist.txt"
FRIENDS_FILE = Path(__file__).parent / "friends.txt"
NOTES_FILE = Path(__file__).parent / "notes.txt"
AVAILABILITY_FILE = Path(__file__).parent / "availability.txt"
OUT_FILE = Path(__file__).parent / "report.html"

# Re-import der Konstanten vom Parser
from parser import (
    DEU_BOOKABLE_MO_FR, TRAINING_COLS, SATURDAY_BOOKABLE, WATCH_COLS,
)

TRAINING_QUOTA = 5  # nach 5 Trainingsdiensten nur noch reguläre Slots
TOP_N_FOR_PATTERNS = 20

# Diese werden beim build_report gesetzt und von Render-Funktionen genutzt
_SHITLIST: set[str] = set()
_FRIENDS: dict[str, str] = {}

# Stundenberechnung
HOURS_PER_HALF = 6.25
HOURS_PER_FULL = 12.5
HOURS_PER_SAT = 7.0
GOAL_PSYCHOLOGY = 240.0
GOAL_PSYCHOTHERAPY = 400.0
PROGRESS_START = date(2026, 5, 4)  # Intro-Tag, davor zählt nichts
PT_COUNT_START = date(2026, 7, 2)  # Fachspezifikum: Stunden ab hier zählen (Propädeutikum vorher abschließen)

LABEL_PSY = "Psychologie Masterpraktikum"
LABEL_PT = "Fachspezifikum"

# Hardcoded-Zusatzeinträge (Dienste die nicht im Kalender sind, oder Boni)
EXTRA_HOURS: list[dict] = [
    {"date": "2026-05-04", "hours": 6.0, "label": "Intro-Training (10–16h)"},
    {"date": "2026-05-05", "hours": 0.5, "label": "Überzeit"},
]

# Hardcoded-Feiertage als Fallback, falls noch nicht im Cache (oder zur Sicherheit)
HOLIDAYS_KNOWN: set[str] = {
    "2026-05-14",  # Christi Himmelfahrt
    "2026-05-25",  # Pfingstmontag
    "2026-06-03",  # Fronleichnam
}

WEEKDAY_DE = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]


def load_favorites() -> set[str]:
    if not FAVORITES_FILE.exists():
        return set()
    return {l.strip() for l in FAVORITES_FILE.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.startswith("#")}


def load_shitlist() -> set[str]:
    if not SHITLIST_FILE.exists():
        return set()
    return {l.strip() for l in SHITLIST_FILE.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.startswith("#")}


def load_friends() -> dict[str, str]:
    """Lädt friends.txt → {label: symbol_char} wobei symbol_char in {A, B, C}."""
    out: dict[str, str] = {}
    if not FRIENDS_FILE.exists():
        return out
    for line in FRIENDS_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.rsplit(" ", 1)
        if len(parts) == 2 and parts[1].upper() in ("A", "B", "C"):
            out[parts[0].strip()] = parts[1].upper()
        else:
            out[line] = "A"  # default Symbol wenn keins angegeben
    return out


STATUS_EMOJI = {
    "sick":  "🤒",
    "late":  "⏰",
    "swap":  "🔄",
    "moved": "↕️",
    "sub":   "⭐",
    "out":   "❌",
    "note":  "📝",
}


def load_notes() -> dict[str, list[dict]]:
    """
    Lädt notes.txt → {date_iso: [{half, label, status, emoji, note}]}
    """
    out: dict[str, list[dict]] = {}
    if not NOTES_FILE.exists():
        return out
    for line in NOTES_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 3)  # date half label status [note]
        if len(parts) < 4:
            continue
        d_iso, half, *rest = parts
        # label kann mehrere Wörter haben (z.B. "Müller, M.")
        # rest = ["Müller, M. sick Notiz"] oder ["Müller,", "M.", "sick", "Notiz"]
        # Wir nehmen alles bis zum letzten bekannten Status-Wort
        rest_str = " ".join(rest)
        status = None
        note_text = ""
        for s in STATUS_EMOJI:
            idx = rest_str.lower().find(s)
            if idx != -1:
                label = rest_str[:idx].strip().rstrip(",").strip()
                remainder = rest_str[idx + len(s):].strip()
                note_text = remainder
                status = s
                break
        if status is None:
            continue
        emoji = STATUS_EMOJI[status]
        half = half.upper()
        out.setdefault(d_iso, []).append({
            "half": half, "label": label, "status": status,
            "emoji": emoji, "note": note_text,
        })
    return out


def person_badges(label: str, favorites: set[str]) -> str:
    """Gibt HTML-Badges für eine Person zurück (nutzt _SHITLIST/_FRIENDS Globals)."""
    parts = []
    if label in favorites:
        friend_sym = _FRIENDS.get(label)
        if friend_sym == "A":
            parts.append('<span class="badge-fav badge-fav-a">♥</span>')
        elif friend_sym == "B":
            parts.append('<span class="badge-fav badge-fav-b">♡</span>')
        elif friend_sym == "C":
            parts.append('<span class="badge-fav badge-fav-c">♦</span>')
        else:
            parts.append('<span class="badge-fav">♥</span>')
    if label in _SHITLIST:
        parts.append('<span class="badge-shit">⚠️</span>')
    return "".join(parts)





_WEEKDAY_MAP = {"MO": 0, "DI": 1, "MI": 2, "DO": 3, "FR": 4, "SA": 5}


def load_availability() -> dict:
    """
    Liest availability.txt und gibt zurück:
    {
      'weekly': {weekday_int: set("AM"|"PM"|"FULL")},
      'free':   {date_iso: set(half)},
      'blocked':{date_iso: set(half)}
    }
    """
    out = {"weekly": {}, "free": {}, "blocked": {}}
    if not AVAILABILITY_FILE.exists():
        return out
    for raw in AVAILABILITY_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        kind, payload = line.split(":", 1)
        kind = kind.strip().lower()
        parts = payload.split()
        if kind == "weekly" and len(parts) == 2:
            wd = _WEEKDAY_MAP.get(parts[0].upper())
            half = parts[1].upper()
            if wd is None or half not in ("AM", "PM", "FULL"):
                continue
            out["weekly"].setdefault(wd, set()).add(half)
        elif kind in ("free", "blocked") and len(parts) == 2:
            date_iso, half = parts[0], parts[1].upper()
            if half not in ("AM", "PM", "FULL"):
                continue
            out[kind].setdefault(date_iso, set()).add(half)
    return out


def availability_for(avail: dict, d_iso: str, weekday: int) -> dict:
    """
    Pro Halbtag: True (frei) / False (nicht frei).
    Returns {'AM': bool, 'PM': bool, 'SAT': bool}.
    """
    # Standard aus weekly
    has_full = "FULL" in avail["weekly"].get(weekday, set())
    free_am = has_full or "AM" in avail["weekly"].get(weekday, set())
    free_pm = has_full or "PM" in avail["weekly"].get(weekday, set())
    free_sat = "FULL" in avail["weekly"].get(5, set())  # SA-FULL

    # Frei-Override (immer additiv)
    free_set = avail["free"].get(d_iso, set())
    if "FULL" in free_set:
        free_am = free_pm = True
    if "AM" in free_set: free_am = True
    if "PM" in free_set: free_pm = True

    # Blocked (überschreibt)
    blocked_set = avail["blocked"].get(d_iso, set())
    if "FULL" in blocked_set:
        free_am = free_pm = False
    if "AM" in blocked_set: free_am = False
    if "PM" in blocked_set: free_pm = False

    return {"AM": free_am, "PM": free_pm, "SAT": free_sat if weekday == 5 else False}

# Team-Gruppierung für die ausklappbare Tagesdetail-Box
TEAM_GROUPS = [
    ("Senior", ["DEU-A-Seniorassistent"], "#fff3cd"),
    ("DEU", ["DEU-B", "DEU-C", "DEU-D", "DEU-E", "DEU-F", "DEU-G"], "#d1e7dd"),
    ("Training", ["Training 1", "Training 2"], "#cfe2ff"),
    ("INT", ["INT-A-Seniorassistent", "INT-B"], "#f8d7da"),
    ("Bindung", ["DEU-Bindung", "DEU-Bindung2"], "#e2d9f3"),
    ("Forschung", ["Forschung 1", "Forschung 2", "Forschung 3",
                   "Forschung 4", "Forschung 5", "Forschung 6"], "#e9ecef"),
]


def load_people() -> dict:
    if PEOPLE_FILE.exists():
        return json.loads(PEOPLE_FILE.read_text(encoding="utf-8"))
    return {"by_member_id": {}, "label_to_member_ids": {}, "entry_to_member_id": {}}


def display_name_for(entry: dict, people: dict) -> str:
    """
    Liefert Anzeigename. Bevorzugt 'Vorname Nachname' wenn auflösbar,
    sonst 'Nachname, V.' (das Label aus dem Tageskalender).
    """
    label = entry.get("person") or "?"
    eid = entry.get("entry_id")
    mid = None
    if eid and eid in people.get("entry_to_member_id", {}):
        mid = people["entry_to_member_id"][eid]
    elif label in people.get("label_to_member_ids", {}):
        ids = people["label_to_member_ids"][label]
        if len(ids) == 1:
            mid = ids[0]
    if mid and mid in people.get("by_member_id", {}):
        info = people["by_member_id"][mid]
        if info.get("first_name"):
            return f"{info['first_name']} {info['last_name']}"
        return info.get("full_name", label)
    return label



# ---------- Hilfsfunktionen Cache → Auswertung ----------

def reconstruct_my_history(cache: dict, today: date,
                           now_time: "time | None" = None) -> dict:
    """
    Geht durch alle gecachten Tage <= heute und baut auf:
      - my_shift_count_total
      - my_training_count
      - coworkers_total: nur Personen mit denen die Schicht zur Hälfte
        durchlaufen ist (siehe shift_halfway_done)
      - my_shift_dates
    """
    from datetime import time as dt_time
    if now_time is None:
        now_time = dt_time(0, 0)

    # Halbzeit-Schwellen (gleiche Logik wie in compute_hours_progress, ~Mitte)
    AM_HALF = dt_time(10, 45)
    PM_HALF = dt_time(17, 0)
    SAT_HALF = dt_time(13, 0)

    def shift_halfway_done(d_date: date, half: str) -> bool:
        if d_date < today:
            return True
        if d_date > today:
            return False
        if half == "AM" or half == "FULL":
            return now_time >= AM_HALF
        if half == "PM":
            return now_time >= PM_HALF
        if half == "SAT":
            return now_time >= SAT_HALF
        return False

    my_name = cache["meta"].get("my_name", "Schwarz, M.")
    coworkers = Counter()
    my_shifts = []
    training_count = 0

    for key, d in sorted(cache["days"].items()):
        d_date = date.fromisoformat(key)
        if d_date > today:
            continue
        my_halves = set()
        for e in d["entries"]:
            if e["person"] == my_name:
                if e["half"] == "FULL":
                    my_halves.update({"AM", "PM"})
                elif e["half"] == "SAT":
                    my_halves.add("SAT")
                else:
                    my_halves.add(e["half"])
                my_shifts.append({"date": key, "half": e["half"], "column": e["column"]})
                if e["column"] in TRAINING_COLS:
                    training_count += 2 if e["half"] == "FULL" else 1
        # Coworker zählen nur wenn meine Schicht zur Hälfte vorbei ist
        # und ihre auch (Überlappung gilt nur für absolvierten Teil)
        for e in d["entries"]:
            if not e["person"] or e["person"] == my_name:
                continue
            e_halves = {"AM", "PM"} if e["half"] == "FULL" else {e["half"]}
            for h in e_halves & my_halves:
                # Sowohl mein Halbtag als auch der andere muss halbiert sein
                if shift_halfway_done(d_date, h):
                    coworkers[e["person"]] += 1
                    break  # ein Eintrag pro Person+Tag genug

    return {
        "my_name": my_name,
        "shift_count": len(my_shifts),
        "training_count": training_count,
        "coworkers": coworkers,
        "shifts": my_shifts,
    }


def people_stats_in_cache(cache: dict) -> dict[str, dict]:
    """
    Pro Person: total Dienste, pro Spalte Counts, AM/PM-Verteilung,
    Schichtmuster (weekday, half) → count.
    """
    stats: dict[str, dict] = defaultdict(lambda: {
        "total": 0, "AM": 0, "PM": 0, "FULL": 0, "SAT": 0,
        "columns": Counter(),
        "patterns": Counter(),
    })
    for d in cache["days"].values():
        wd = d["weekday"]
        for e in d["entries"]:
            if not e["person"]:
                continue
            s = stats[e["person"]]
            s["total"] += 1
            s[e["half"]] += 1
            s["columns"][e["column"]] += 1
            half_label = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}[e["half"]]
            s["patterns"][(wd, half_label)] += 1
    return stats


def format_pattern(patterns: Counter, max_items: int = 4) -> str:
    """'Di-NM ×4, Mi-VM ×3' — die häufigsten Slots."""
    if not patterns:
        return "—"
    items = patterns.most_common(max_items)
    parts = []
    for (wd, half), ct in items:
        wd_str = WEEKDAY_DE[wd]
        if ct == 1:
            parts.append(f"{wd_str}-{half}")
        else:
            parts.append(f"{wd_str}-{half} ×{ct}")
    return ", ".join(parts)


def upcoming_shared_shifts(cache: dict, my_name: str, today: date,
                           limit: int = 4) -> tuple[dict[str, list[str]], dict[str, date]]:
    """
    Pro Person:
    - Liste von bis zu `limit` zukünftigen gemeinsamen Diensten als Strings.
    - Frühestes gemeinsames Datum (für Sortierung).
    """
    half_short = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}
    result: dict[str, list[str]] = {}
    next_date: dict[str, date] = {}

    for key in sorted(cache["days"].keys()):
        d_date = date.fromisoformat(key)
        if d_date < today:
            continue
        d = cache["days"][key]
        my_halves: set[str] = set()
        for e in d["entries"]:
            if e["person"] == my_name:
                if e["half"] == "FULL":
                    my_halves.update({"AM", "PM"})
                else:
                    my_halves.add(e["half"])
        if not my_halves:
            continue
        for e in d["entries"]:
            if not e["person"] or e["person"] == my_name:
                continue
            e_halves = {"AM", "PM"} if e["half"] == "FULL" else {e["half"]}
            overlap = e_halves & my_halves
            if not overlap:
                continue
            short_date = f"{d_date.day}.{d_date.month}"
            half_lbl = half_short[e["half"]]
            entry_str = f"{short_date} {half_lbl}"
            lst = result.setdefault(e["person"], [])
            if len(lst) < limit and entry_str not in lst:
                lst.append(entry_str)
            if e["person"] not in next_date:
                next_date[e["person"]] = d_date
    return result, next_date


# ---------- Verfügbarkeits-Berechnung pro Tag ----------

def compute_day_summary(d: dict, my_history: dict, favorites: set[str],
                        shitlist: set[str] | None = None,
                        notes: dict | None = None) -> dict:
    """
    Berechnet pro Halbtag: Slot-Verfügbarkeit + Bekanntschafts-Indikator
    + Favoriten-Count.
    """
    is_sat = d["is_saturday"]
    coworkers = my_history["coworkers"]
    my_name = my_history["my_name"]
    shitlist = shitlist or set()
    notes = notes or {}
    d_notes = notes.get(d["date"], [])
    out = {"date": d["date"], "weekday": d["weekday"], "is_saturday": is_sat,
           "notes": d_notes, "halves": {}}

    if is_sat:
        taken = 0
        people = []
        for e in d["entries"]:
            if e["column"] in SATURDAY_BOOKABLE:
                taken += 1
                if e["person"]:
                    people.append(e["person"])
        watch_people = [
            e["person"] for e in d["entries"]
            if e["column"] in ("DEU-A-Seniorassistent", "INT-A-Seniorassistent") and e["person"]
        ]
        all_people = people + watch_people
        known = sum(1 for p in all_people if p != my_name and coworkers.get(p, 0) > 0)
        fav_count = sum(1 for p in all_people if p != my_name and p in favorites)
        shit_count = sum(1 for p in all_people if p != my_name and p in shitlist)
        out["halves"]["SAT"] = {
            "deu_taken": taken, "deu_total": len(SATURDAY_BOOKABLE),
            "training_taken": 0, "training_total": 0,
            "people": people, "watch_people": watch_people,
            "known_count": known, "favorite_count": fav_count,
            "shit_count": shit_count,
            "i_am_in": my_name in all_people,
        }
        return out

    for half in ("AM", "PM"):
        deu_taken = 0
        deu_people = []
        for e in d["entries"]:
            if e["column"] in DEU_BOOKABLE_MO_FR and (e["half"] == half or e["half"] == "FULL"):
                deu_taken += 1
                if e["person"]:
                    deu_people.append(e["person"])
        tr_taken = 0
        tr_people = []
        for e in d["entries"]:
            if e["column"] in TRAINING_COLS and (e["half"] == half or e["half"] == "FULL"):
                tr_taken += 1
                if e["person"]:
                    tr_people.append(e["person"])
        watch_people = []
        for e in d["entries"]:
            if e["column"] in WATCH_COLS and (e["half"] == half or e["half"] == "FULL"):
                if e["person"]:
                    watch_people.append(e["person"])
        all_people = deu_people + tr_people + watch_people
        known = sum(1 for p in all_people if p != my_name and coworkers.get(p, 0) > 0)
        fav_count = sum(1 for p in all_people if p != my_name and p in favorites)
        shit_count = sum(1 for p in all_people if p != my_name and p in shitlist)
        out["halves"][half] = {
            "deu_taken": deu_taken, "deu_total": len(DEU_BOOKABLE_MO_FR),
            "training_taken": tr_taken, "training_total": len(TRAINING_COLS),
            "people": deu_people, "training_people": tr_people,
            "watch_people": watch_people,
            "known_count": known, "favorite_count": fav_count,
            "shit_count": shit_count,
            "i_am_in": my_name in all_people,
        }
    return out


# ---------- HTML-Rendering ----------

def render_day_details(d: dict, summary: dict, my_history: dict, all_stats: dict,
                       people: dict, favorites: set[str], day_id: str,
                       d_iso: str, today: date) -> str:
    """
    Vollständige Detail-Box für das Modal-Popup.
    """
    coworkers = my_history["coworkers"]
    my_name = my_history["my_name"]
    half_label = {"AM": "VM", "PM": "NM", "FULL": "Ganztags", "SAT": "Sa"}
    weekday_de = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]

    is_past = date.fromisoformat(d_iso) < today

    half_state: dict[str, str] = {}
    for hk, h in summary.get("halves", {}).items():
        if h["i_am_in"]:
            half_state[hk] = ""
            continue
        # Vergangenheit ohne mich → ausblenden
        if is_past:
            half_state[hk] = "past-not-mine"
            continue
        deu_free = (h["deu_total"] - h["deu_taken"]) > 0
        tr_free = (h["training_total"] - h["training_taken"]) > 0
        if not deu_free and not tr_free:
            half_state[hk] = "full-all"
        elif not deu_free:
            half_state[hk] = "full-deu"
        else:
            half_state[hk] = ""

    # Slot-Übersicht oben im Popup
    overview_rows = []
    for hk in ("AM", "PM", "SAT"):
        if hk not in summary.get("halves", {}):
            continue
        h = summary["halves"][hk]
        free_d = h["deu_total"] - h["deu_taken"]
        free_t = h["training_total"] - h["training_taken"]
        state = half_state.get(hk, "")
        row_cls = f"modal-half-row {state}".strip()
        me_marker = ' <span class="me">DU</span>' if h["i_am_in"] else ''
        deu_str = (f'<span class="slot deu" style="background:{color_for_fill(h["deu_taken"], h["deu_total"])}">'
                   f'DEU {h["deu_taken"]}/{h["deu_total"]}</span>')
        tr_str = ''
        if h["training_total"]:
            tr_str = (f'<span class="slot tr" style="background:{color_for_fill(h["training_taken"], h["training_total"])}">'
                      f'Training {h["training_taken"]}/{h["training_total"]}</span>')
        free_note = []
        if free_d > 0: free_note.append(f"{free_d} DEU frei")
        if free_t > 0: free_note.append(f"{free_t} T frei")
        free_str = " · ".join(free_note) if free_note else "voll"
        overview_rows.append(
            f'<div class="{row_cls}">'
            f'<span class="modal-half-name">{half_label[hk]}</span>'
            f'{deu_str}{tr_str}'
            f'<span class="modal-half-note">{free_str}</span>{me_marker}'
            f'</div>'
        )

    # Team-Boxen
    boxes = []
    for team_name, cols, bg_color in TEAM_GROUPS:
        # Sammle Einträge des Teams gruppiert nach Halbtag
        by_half: dict[str, list[dict]] = {"AM": [], "PM": [], "FULL": [], "SAT": []}
        for e in d["entries"]:
            if e["column"] in cols and e["person"]:
                by_half[e["half"]].append(e)
        if not any(by_half.values()):
            continue

        rows = []
        order = ["FULL", "AM", "PM", "SAT"]
        for half in order:
            ents = by_half[half]
            if not ents:
                continue
            if half == "FULL":
                am_state = half_state.get("AM", "")
                pm_state = half_state.get("PM", "")
                row_state = "full-all" if (am_state == "full-all" and pm_state == "full-all") \
                    else ("full-deu" if (am_state in ("full-deu", "full-all")
                                         and pm_state in ("full-deu", "full-all")) else "")
            else:
                row_state = half_state.get(half, "")

            # Pro Eintrag eine Zeile: [VM] DEU-B · Max Müller (3/12 mit mir)
            person_rows = []
            for e in ents:
                disp = display_name_for(e, people)
                badges = person_badges(e["person"], favorites)
                col_badge = f'<span class="modal-col">{escape(e["column"])}</span>'
                if e["person"] == my_name:
                    person_rows.append(
                        f'<div class="modal-person me-detail">{col_badge}'
                        f'<span>{escape(disp)}</span></div>'
                    )
                elif coworkers.get(e["person"], 0) > 0:
                    n_with_me = coworkers[e["person"]]
                    n_total = all_stats.get(e["person"], {}).get("total", 0)
                    person_rows.append(
                        f'<div class="modal-person known person-link" data-pid="{_pid_for(e["person"])}"><span class="known-name">{col_badge}'
                        f'{escape(disp)}{badges}</span>'
                        f' <small class="muted">{n_with_me}× mit mir / {n_total} gesamt</small></div>'
                    )
                else:
                    n_total = all_stats.get(e["person"], {}).get("total", 0)
                    total_note = f' <small class="muted">{n_total} Dienste</small>' if n_total else ''
                    person_rows.append(
                        f'<div class="modal-person person-link" data-pid="{_pid_for(e["person"])}">{col_badge}<span>{escape(disp)}{badges}</span>{total_note}</div>'
                    )
            half_block = (
                f'<div class="modal-team-half {row_state}">'
                f'<div class="modal-half-label">{half_label[half]}</div>'
                f'<div class="modal-persons">{"".join(person_rows)}</div>'
                f'</div>'
            )
            rows.append(half_block)

        boxes.append(
            f'<div class="modal-team-box" style="border-left: 4px solid {bg_color}; background: {bg_color}22;">'
            f'<h4 class="modal-team-name">{team_name}</h4>'
            f'{"".join(rows)}'
            f'</div>'
        )

    if not boxes and not overview_rows:
        return ''

    weekday = summary.get("weekday", 0)
    wd_name = weekday_de[weekday]
    title = f'{wd_name}, {d_iso}'

    # Rolecall-Buttons für Halbtage mit DEU-Belegung
    rc_buttons = []
    half_short_map = {"AM": "VM", "PM": "NM", "SAT": "Sa"}
    for hk in ("AM", "PM", "SAT"):
        if hk not in summary.get("halves", {}):
            continue
        has_deu = any(e["column"] in ROLECALL_COLS for e in d["entries"]
                      if e["half"] == hk or e["half"] == "FULL")
        if has_deu:
            rc_id = f"rc-{day_id}-{hk}"
            rc_buttons.append(
                f'<button class="btn-rolecall btn-rolecall-small" '
                f'onclick="event.stopPropagation();openRolecall(\'{rc_id}\')">'
                f'📋 Rolecall {half_short_map.get(hk, hk)}</button>'
            )
    rc_bar = (f'<div class="rc-modal-bar">{"".join(rc_buttons)}</div>'
              if rc_buttons else '')

    return (
        f'<div id="det-{day_id}" class="day-details" data-title="{escape(title)}" style="display:none">'
        f'{rc_bar}'
        f'<div class="modal-overview">{"".join(overview_rows)}</div>'
        f'<div class="modal-teams">{"".join(boxes)}</div>'
        f'</div>'
    )



    """0 → grün, voll → rot, dazwischen Verlauf."""
    if total == 0:
        return "#eee"
    ratio = taken / total
    # HSL: 120 (grün) → 0 (rot)
    hue = int(120 * (1 - ratio))
    return f"hsl({hue}, 65%, 75%)"


def color_for_fill(taken: int, total: int) -> str:
    """0 → grün, voll → rot, dazwischen Verlauf."""
    if total == 0:
        return "#eee"
    ratio = taken / total
    hue = int(120 * (1 - ratio))
    return f"hsl({hue}, 65%, 75%)"


def render_half_cell(half_key: str, h: dict, training_done: bool,
                     i_have_time: bool | None = None,
                     is_past: bool = False) -> str:
    """Eine kleine Box pro Halbtag (AM/PM/SAT)."""
    deu_color = color_for_fill(h["deu_taken"], h["deu_total"])
    tr_color = color_for_fill(h["training_taken"], h["training_total"]) if h["training_total"] else "#eee"

    known = h["known_count"]
    fav_count = h.get("favorite_count", 0)
    total_people = len(h["people"]) + len(h.get("training_people", [])) + len(h["watch_people"])
    badge = ""
    if known > 0:
        badge = f'<span class="known" title="{known} Bekannte unter {total_people} Anwesenden">★{known}</span>'
    fav_badge = ""
    if fav_count > 0:
        if fav_count == 1:
            fav_badge = '<span class="fav-badge" title="1 Favorit anwesend">♥</span>'
        else:
            fav_badge = f'<span class="fav-badge" title="{fav_count} Favoriten anwesend">♥{fav_count}</span>'
    shit_count = h.get("shit_count", 0)
    shit_badge = (f'<span class="shit-badge" title="{shit_count} Shitlist-Person(en) anwesend">⚠️</span>'
                  if shit_count > 0 else "")
    me = ' <span class="me">DU</span>' if h["i_am_in"] else ""

    deu_label = (f'<span class="slot deu" style="background:{deu_color}" '
                 f'title="{h["deu_taken"]} von {h["deu_total"]} besetzt">'
                 f'D {h["deu_taken"]}/{h["deu_total"]}</span>')
    tr_label_full = (f'<span class="slot tr" style="background:{tr_color}" '
                     f'title="{h["training_taken"]} von {h["training_total"]} besetzt">'
                     f'T {h["training_taken"]}/{h["training_total"]}</span>')
    tr_label_small = (f'<span class="slot tr small" style="background:{tr_color}" '
                      f'title="{h["training_taken"]} von {h["training_total"]} besetzt">'
                      f'T {h["training_taken"]}/{h["training_total"]}</span>')

    if not training_done and h["training_total"] > 0:
        primary = tr_label_full
        secondary = deu_label
    else:
        primary = deu_label
        secondary = tr_label_small if h["training_total"] > 0 else ''

    label = {"AM": "VM", "PM": "NM", "SAT": "Sa"}[half_key]

    extra_classes = []
    if not h["i_am_in"]:
        deu_free = h["deu_total"] - h["deu_taken"]
        tr_free = h["training_total"] - h["training_taken"]
        if deu_free <= 0:
            extra_classes.append("full-deu")
        if deu_free <= 0 and tr_free <= 0:
            extra_classes.append("full-all")
        if is_past:
            extra_classes.append("past-not-mine")
    if i_have_time is True:
        extra_classes.append("avail-yes")
    elif i_have_time is False:
        extra_classes.append("avail-no")
    cls = " ".join(["half"] + extra_classes)

    return (
        f'<div class="{cls}">'
        f'<span class="hl">{label}</span>{primary}{secondary}{badge}{fav_badge}{shit_badge}{me}'
        f'</div>'
    )


def render_day_cell(d_iso: str, summary: dict | None, training_done: bool,
                    in_range: bool, raw_day: dict | None,
                    my_history: dict, all_stats: dict, people: dict,
                    favorites: set[str], availability: dict,
                    today: date) -> str:
    day_num = int(d_iso.split("-")[2])
    if not in_range:
        return f'<td class="out"><span class="dn">{day_num}</span></td>'
    is_holiday = (raw_day and raw_day.get("is_holiday")) or d_iso in HOLIDAYS_KNOWN
    if is_holiday:
        return (f'<td class="holiday"><span class="dn">{day_num}</span>'
                f'<div class="holiday-label">Feiertag</div></td>')
    if summary is None:
        return f'<td class="empty"><span class="dn">{day_num}</span></td>'

    weekday = summary["weekday"]
    avail_per_half = availability_for(availability, d_iso, weekday)
    is_past = date.fromisoformat(d_iso) < today

    halves_html = ""
    any_half = False
    all_deu_full = True
    all_full = True
    i_am_in_any = False
    for hk in ("AM", "PM", "SAT"):
        if hk in summary["halves"]:
            any_half = True
            h = summary["halves"][hk]
            deu_free = (h["deu_total"] - h["deu_taken"]) > 0
            tr_free = (h["training_total"] - h["training_taken"]) > 0
            if h["i_am_in"]:
                i_am_in_any = True
            if h["i_am_in"] or deu_free:
                all_deu_full = False
            if h["i_am_in"] or deu_free or tr_free:
                all_full = False
            halves_html += render_half_cell(hk, h, training_done,
                                            i_have_time=avail_per_half[hk],
                                            is_past=is_past)

    # Notes für diesen Tag
    day_notes = summary.get("notes", [])
    notes_html = ""
    if day_notes:
        note_parts = []
        for n in day_notes:
            tip = f'{n["label"]} {n["half"]}'
            if n.get("note"):
                tip += f': {n["note"]}'
            note_parts.append(f'<span class="day-note" title="{escape(tip)}">{n["emoji"]}</span>')
        notes_html = f'<div class="day-notes">{"".join(note_parts)}</div>'
    day_id = d_iso.replace("-", "")
    details = (render_day_details(raw_day, summary, my_history, all_stats, people,
                                  favorites, day_id, d_iso, today) if raw_day else '')
    classes = ["day"]
    if any_half and all_deu_full:
        classes.append("all-full-deu")
    if any_half and all_full:
        classes.append("all-full-all")
    if is_past and not i_am_in_any:
        classes.append("past-not-mine")
    full_hint = ('<div class="all-full-hint">alles voll</div>'
                 if (any_half and all_deu_full) else '')
    past_hint = ('<div class="all-full-hint">vergangen</div>'
                 if (is_past and not i_am_in_any) else '')
    return (f'<td class="{" ".join(classes)}" data-day-id="{day_id}">'
            f'<span class="dn">{day_num}</span>{notes_html}'
            f'{halves_html}{full_hint}{past_hint}{details}</td>')


def render_month(year: int, month: int, summaries: dict, raw_days: dict,
                 training_done: bool, today: date,
                 my_history: dict, all_stats: dict, people: dict,
                 favorites: set[str], availability: dict) -> str:
    cal = calendar.Calendar(firstweekday=0)  # Mo
    month_name = ["Jänner","Februar","März","April","Mai","Juni",
                  "Juli","August","September","Oktober","November","Dezember"][month-1]
    out = [f'<h2>{month_name} {year}</h2>']
    out.append('<table class="cal">')
    out.append('<thead><tr><th>Mo</th><th>Di</th><th>Mi</th><th>Do</th><th>Fr</th><th>Sa</th><th>So</th></tr></thead>')
    out.append('<tbody>')
    for week in cal.monthdatescalendar(year, month):
        out.append('<tr>')
        for d in week:
            in_range = d.month == month
            if d.weekday() == 6:  # Sonntag
                # Kein Sonntag-Dienst, aber Tag anzeigen
                if in_range:
                    out.append(f'<td class="sun"><span class="dn">{d.day}</span></td>')
                else:
                    out.append(f'<td class="out"><span class="dn">{d.day}</span></td>')
                continue
            iso = d.isoformat()
            summary = summaries.get(iso)
            raw = raw_days.get(iso)
            cell = render_day_cell(iso, summary, training_done, in_range,
                                   raw, my_history, all_stats, people, favorites,
                                   availability, today)
            # heute-Markierung
            if d == today and in_range:
                cell = cell.replace('<td class="', '<td class="today ', 1)
            out.append(cell)
        out.append('</tr>')
    out.append('</tbody></table>')
    return "\n".join(out)


def _person_display(label: str, people: dict) -> str:
    ids = people.get("label_to_member_ids", {}).get(label, [])
    if len(ids) == 1:
        info = people.get("by_member_id", {}).get(ids[0], {})
        if info.get("first_name"):
            return f"{info['first_name']} {info['last_name']}"
    return label


def sort_key_persons(person: str, favorites: set[str],
                     coworkers: Counter, all_stats: dict,
                     next_shared_date: dict[str, date]) -> tuple:
    """
    Sortierung:
      1. Favoriten zuerst
      2. dann nach nächstem gemeinsamen Dienst (frühestes Datum zuerst,
         keinen → ans Ende)
      3. dann nach Anzahl gemeinsamer Dienste (absteigend)
      4. dann nach Gesamtdienstanzahl (absteigend)
      5. Name als Tiebreaker
    """
    is_fav = 0 if person in favorites else 1
    nd = next_shared_date.get(person)
    nd_key = nd.toordinal() if nd else 999999
    co = -coworkers.get(person, 0)
    total = -all_stats.get(person, {}).get("total", 0)
    return (is_fav, nd_key, co, total, person)


def render_people_stats(my_history: dict, all_stats: dict[str, dict],
                        people: dict, favorites: set[str],
                        upcoming: dict[str, list[str]],
                        next_shared_date: dict[str, date]) -> str:
    coworkers = my_history["coworkers"]
    my_name = my_history["my_name"]
    if coworkers:
        max_count = max(coworkers.values())
    else:
        max_count = 0

    rows = []
    sorted_coworkers = sorted(
        coworkers.keys(),
        key=lambda p: sort_key_persons(p, favorites, coworkers, all_stats, next_shared_date)
    )
    for person in sorted_coworkers:
        ct = coworkers[person]
        ps = all_stats.get(person, {})
        total = ps.get("total", 0)
        am = ps.get("AM", 0); pm = ps.get("PM", 0)
        pattern = format_pattern(ps.get("patterns", Counter()))
        intensity = ct / max_count if max_count else 0
        bg = f"hsl(45, 90%, {100 - int(intensity*30)}%)"
        badges = person_badges(person, favorites)
        upcoming_str = ", ".join(upcoming.get(person, [])) or "—"
        pid = _pid_for(person)
        rows.append(
            f'<tr style="background:{bg}">'
            f'<td class="person-link" data-pid="{pid}"><b>{escape(_person_display(person, people))}</b>{badges}</td>'
            f'<td class="num">{ct}</td>'
            f'<td class="num">{total}</td>'
            f'<td class="num">{am}/{pm}</td>'
            f'<td class="pattern">{escape(pattern)}</td>'
            f'<td class="upcoming">{escape(upcoming_str)}</td>'
            f'</tr>'
        )

    unknown_persons = [p for p in all_stats
                       if p != my_name and p not in coworkers]
    unknown_persons.sort(
        key=lambda p: sort_key_persons(p, favorites, coworkers, all_stats, next_shared_date)
    )

    unknown_rows = ""
    for person in unknown_persons[:30]:
        ps = all_stats.get(person, {})
        total = ps.get("total", 0)
        pattern = format_pattern(ps.get("patterns", Counter()))
        badges = person_badges(person, favorites)
        upcoming_str = ", ".join(upcoming.get(person, [])) or "—"
        pid = _pid_for(person)
        unknown_rows += (
            f'<tr><td class="person-link" data-pid="{pid}">{escape(_person_display(person, people))}{badges}</td>'
            f'<td class="num">{total}</td>'
            f'<td class="pattern">{escape(pattern)}</td>'
            f'<td class="upcoming">{escape(upcoming_str)}</td></tr>'
        )

    html = f'''
    <section class="known-section">
    <h2>Mit wem ich bisher Dienst hatte</h2>
    <p>Insgesamt <b>{my_history["shift_count"]}</b> Diensteinträge,
       davon <b>{my_history["training_count"]}</b> Training.
       {len(coworkers)} verschiedene Kolleg:innen.
       Favoriten: <b>{len(favorites)}</b> (♥ in <code>favorites.txt</code> verwaltet).</p>
    <table class="stats">
      <thead><tr>
        <th>Person</th><th>mit mir</th><th>gesamt</th><th>VM/NM</th>
        <th>häufige Schichten</th><th>nächste gemeinsam</th>
      </tr></thead>
      <tbody>{"".join(rows) if rows else '<tr><td colspan=6>Noch keine Dienste.</td></tr>'}</tbody>
    </table>

    <h3>Aktive Kolleg:innen, die ich noch nicht kenne <span class="muted">(top 30 nach Dienstanzahl)</span></h3>
    <table class="stats">
      <thead><tr><th>Person</th><th>Dienste</th><th>häufige Schichten</th><th>nächste gemeinsam</th></tr></thead>
      <tbody>{unknown_rows or '<tr><td colspan=4>—</td></tr>'}</tbody>
    </table>
    </section>
    '''
    return html


def render_shift_patterns(cache: dict, all_stats: dict[str, dict],
                          my_history: dict, people: dict,
                          favorites: set[str],
                          next_shared_date: dict[str, date],
                          today: date) -> str:
    """
    Detaillierte Schichtmuster — sortiert nach Favoriten, dann nächster
    gemeinsamer Dienst, dann gemeinsame Dienste, dann Gesamt.
    """
    coworkers = my_history["coworkers"]
    my_name = my_history["my_name"]

    training_people: set[str] = set()
    for d in cache["days"].values():
        for e in d["entries"]:
            if e["column"] in TRAINING_COLS and e["person"]:
                training_people.add(e["person"])

    top_n = sorted(all_stats.items(), key=lambda x: -x[1]["total"])[:TOP_N_FOR_PATTERNS]
    top_n_set = {p for p, _ in top_n}

    selected = (training_people | set(coworkers.keys()) | top_n_set | favorites) - {my_name}
    ordered = sorted(
        selected,
        key=lambda p: sort_key_persons(p, favorites, coworkers, all_stats, next_shared_date)
    )

    # Heatmap: Wochentage Mo-Sa (5 Tage + Sa); Halbtage VM, NM (+ Sa)
    halves_layout = ["VM", "NM"]
    rows = []
    for person in ordered:
        ps = all_stats.get(person, {})
        patterns = ps.get("patterns", Counter())
        total = ps.get("total", 0)
        with_me = coworkers.get(person, 0)
        max_in_pattern = max(patterns.values()) if patterns else 0

        cells = []
        for wd in range(5):  # Mo-Fr
            for half in halves_layout:
                ct = patterns.get((wd, half), 0)
                if ct == 0:
                    cells.append('<td class="pat-cell"></td>')
                else:
                    intensity = ct / max_in_pattern if max_in_pattern else 0
                    # Skala blau (selten) → dunkelblau (häufig)
                    light = 90 - int(intensity * 35)
                    cells.append(
                        f'<td class="pat-cell" style="background:hsl(210,70%,{light}%);'
                        f'color:{"white" if intensity > 0.6 else "#222"}">{ct}</td>'
                    )
        # Samstag-Spalte
        sat_ct = patterns.get((5, "Sa"), 0)
        if sat_ct:
            cells.append(f'<td class="pat-cell pat-sat" '
                         f'style="background:hsl(45,70%,{90 - int((sat_ct/max_in_pattern)*35)}%)">{sat_ct}</td>')
        else:
            cells.append('<td class="pat-cell pat-sat"></td>')

        tags = []
        if person in coworkers:
            tags.append(f'<span class="tag tag-co" title="{with_me}× mit mir">⊕{with_me}</span>')
        if person in training_people:
            tr_count, tr_done = training_progress_for(person, cache, today)
            if tr_done:
                tr_date = date.fromisoformat(tr_done)
                delta = (tr_date - today).days
                if delta == 0:
                    rel = "heute"
                elif delta > 0:
                    rel = f"in {delta} T."
                else:
                    rel = f"vor {-delta} T."
                if tr_count >= TRAINING_QUOTA:
                    tr_label = f'T ✓ {tr_date.day}.{tr_date.month}. ({rel})'
                    tr_title = f'Training abgeschlossen am {tr_done}'
                    tr_cls = 'tag tag-tr tag-tr-done'
                else:
                    tr_label = f'T {tr_count}/{TRAINING_QUOTA} → {tr_date.day}.{tr_date.month}. ({rel})'
                    tr_title = f'{tr_count}/{TRAINING_QUOTA} — letzter gebuchter Dienst am {tr_done}'
                    tr_cls = 'tag tag-tr'
            else:
                tr_label = f'T 0/{TRAINING_QUOTA}'
                tr_title = 'Noch keine Trainingsdienste gebucht'
                tr_cls = 'tag tag-tr'
            tags.append(f'<span class="{tr_cls}" title="{tr_title}">{tr_label}</span>')
        if person in favorites:
            tags.append('<span class="tag tag-fav">♥</span>')

        rows.append(
            f'<tr>'
            f'<td class="pat-name person-link" data-pid="{_pid_for(person)}">{escape(_person_display(person, people))} {"".join(tags)}</td>'
            f'<td class="num pat-total">{total}</td>'
            + "".join(cells) +
            f'</tr>'
        )

    if not rows:
        return ''

    # Header der Heatmap
    head_cells = []
    for wd in range(5):
        for half in halves_layout:
            head_cells.append(f'<th class="pat-cell">{WEEKDAY_DE[wd]}<br><small>{half}</small></th>')
    head_cells.append('<th class="pat-cell pat-sat">Sa</th>')

    return f'''
    <section class="known-section">
    <h2>Schichtmuster (Wochentag × Halbtag)</h2>
    <p class="muted">Trainings-Personen, Kolleg:innen mit denen ich Dienst hatte,
       Top-{TOP_N_FOR_PATTERNS} nach Dienstanzahl, sowie Favoriten ♥.
       Zelle = Anzahl Dienste in diesem Cache. Dunkler = häufiger.
       <span class="tag tag-co">⊕N</span> = N gemeinsame Dienste,
       <span class="tag tag-tr">T 3/5</span> = Training (Fortschritt),
       <span class="tag tag-tr-done">T ✓</span> = Training abgeschlossen,
       <span class="tag tag-fav">♥</span> = Favorit.</p>
    <table class="stats pattern-table">
      <thead><tr><th>Person</th><th>Σ</th>{"".join(head_cells)}</tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
    </section>
    '''


def _pid_for(label: str) -> str:
    """Stabile ID aus einem Personen-Label (für data-pid)."""
    import hashlib
    return "p" + hashlib.md5(label.encode("utf-8")).hexdigest()[:10]


def training_progress_for(label: str, cache: dict, today: date) -> tuple[int, str | None]:
    """
    Zählt Trainings-Halbtage für eine Person.
    Rückgabe: (count, key_date_iso)
      - Falls count >= TRAINING_QUOTA: key_date = Tag des Abschlusses
      - Falls count < TRAINING_QUOTA: key_date = letzter gebuchter Trainingsdienst
      - Falls count == 0: key_date = None
    """
    count = 0
    done_date = None
    last_booked = None
    for key in sorted(cache["days"].keys()):
        for e in cache["days"][key]["entries"]:
            if e["person"] == label and e["column"] in TRAINING_COLS:
                prev = count
                count += 2 if e["half"] == "FULL" else 1
                last_booked = key
                if prev < TRAINING_QUOTA <= count and done_date is None:
                    done_date = key
    if done_date:
        return count, done_date
    return count, last_booked


def render_person_card(label: str, all_stats: dict, people: dict,
                       coworkers: Counter, favorites: set[str],
                       upcoming: dict[str, list[str]],
                       my_shifts_by_date: dict[date, set[str]],
                       cache: dict, my_name: str, today: date) -> str:
    """Detail-Karte für eine Person (versteckt, beim Klick im Modal angezeigt)."""
    pid = _pid_for(label)
    ps = all_stats.get(label, {})
    total = ps.get("total", 0)
    am = ps.get("AM", 0); pm = ps.get("PM", 0)
    full_cnt = ps.get("FULL", 0); sat = ps.get("SAT", 0)
    cols = ps.get("columns", Counter())
    patterns = ps.get("patterns", Counter())
    with_me = coworkers.get(label, 0)
    badges = person_badges(label, favorites)
    disp = _person_display(label, people)
    label_full = label if disp == label else f"{disp} <span class='muted'>({label})</span>"

    cols_html = ""
    if cols:
        items = [f'<span class="modal-col">{escape(c)}</span> <span class="num">{n}</span>'
                 for c, n in cols.most_common()]
        cols_html = '<div class="card-cols">' + " · ".join(items) + '</div>'

    halves_layout = ["VM", "NM"]
    max_in = max(patterns.values()) if patterns else 0
    pat_cells = []
    for wd in range(5):
        for half in halves_layout:
            ct = patterns.get((wd, half), 0)
            if ct == 0:
                pat_cells.append('<td class="pat-cell"></td>')
            else:
                intensity = ct / max_in if max_in else 0
                light = 90 - int(intensity * 35)
                color = "white" if intensity > 0.6 else "#222"
                pat_cells.append(f'<td class="pat-cell" style="background:hsl(210,70%,{light}%);color:{color}">{ct}</td>')
    sat_ct = patterns.get((5, "Sa"), 0)
    if sat_ct:
        pat_cells.append(f'<td class="pat-cell pat-sat" style="background:hsl(45,70%,{90 - int((sat_ct/max_in)*35)}%)">{sat_ct}</td>')
    else:
        pat_cells.append('<td class="pat-cell pat-sat"></td>')
    head_cells = []
    weekday_de = ["Mo", "Di", "Mi", "Do", "Fr"]
    for wd in range(5):
        for half in halves_layout:
            head_cells.append(f'<th class="pat-cell">{weekday_de[wd]}<br><small>{half}</small></th>')
    head_cells.append('<th class="pat-cell pat-sat">Sa</th>')

    half_short = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}
    past_shared = []
    for key in sorted(cache["days"].keys()):
        d_date = date.fromisoformat(key)
        if d_date > today:
            continue
        my_halves = my_shifts_by_date.get(d_date, set())
        if not my_halves:
            continue
        d = cache["days"][key]
        for e in d["entries"]:
            if e["person"] != label:
                continue
            e_halves = {"AM", "PM"} if e["half"] == "FULL" else {e["half"]}
            if e_halves & my_halves:
                past_shared.append((d_date, e["half"], e["column"]))
                break

    upcoming_str = ", ".join(upcoming.get(label, [])) or "—"
    past_str = ", ".join(f"{d.day}.{d.month} {half_short[h]}" for d, h, _ in past_shared[-8:]) or "—"

    # Training-Chronologie (nur wenn Person in Training-Spalten vorkommt)
    training_html = ""
    training_entries = []
    for key in sorted(cache["days"].keys()):
        for e in cache["days"][key]["entries"]:
            if e["person"] == label and e["column"] in TRAINING_COLS:
                training_entries.append((key, e["half"], e["column"]))
    if training_entries:
        count = 0
        rows_t = []
        done_date = None
        half_short_t = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}
        for d_iso, half, col in training_entries:
            prev_count = count
            count += 2 if half == "FULL" else 1
            d_date = date.fromisoformat(d_iso)
            is_p = d_date <= today
            milestone = ""
            if prev_count < TRAINING_QUOTA <= count:
                milestone = ' <span class="training-done">✓ Abschluss</span>'
                if done_date is None:
                    done_date = d_iso
            rows_t.append(
                f'<div class="training-entry {"past" if is_p else "future"}">'
                f'<span class="training-date">{d_date.day}.{d_date.month}.{d_date.year}</span>'
                f'<span class="training-half">{half_short_t[half]}</span>'
                f'<span class="training-col">{escape(col)}</span>'
                f'<span class="training-count">#{count}</span>'
                f'{milestone}</div>'
            )
        if done_date and date.fromisoformat(done_date) <= today:
            done_note = f'<div class="training-summary done">✓ Fertig am <b>{done_date}</b></div>'
        elif done_date:
            done_note = f'<div class="training-summary future">Voraussichtlich fertig: <b>{done_date}</b></div>'
        else:
            done_note = f'<div class="training-summary open">{count}/{TRAINING_QUOTA} — noch {TRAINING_QUOTA - count} Halbtag(e) offen</div>'
        training_html = f'''
      <div class="card-section">
        <div class="card-section-label">Trainingsdienste ({count}/{TRAINING_QUOTA})</div>
        {done_note}
        <div class="training-list">{"".join(rows_t)}</div>
      </div>'''

    is_fav = label in favorites
    fav_status = ('<span class="fav-yes">★ Favorit</span>' if is_fav
                  else '<span class="fav-no">kein Favorit</span>')
    # Button kopiert die exakte favorites.txt-Zeile in die Zwischenablage
    fav_action = (
        f'<button class="fav-copy-btn" '
        f'onclick="copyFav(this, {json.dumps(label)})">'
        f'{"Label kopieren" if is_fav else "Als Favorit kopieren"}</button>'
    )
    return f'''
    <div id="card-{pid}" class="person-card" style="display:none"
         data-title="{escape(disp)}">
      <div class="card-header">
        <h3>{label_full}{badges}</h3>
        <div class="muted">{total} Dienste insgesamt · {with_me}× mit mir</div>
        <div class="fav-row">{fav_status} {fav_action}
          <span class="fav-hint muted">→ Zeile in <code>favorites.txt</code> einfügen, dann Report neu generieren</span>
        </div>
      </div>
      <div class="card-grid">
        <div class="card-stat"><div class="card-label">VM</div><div class="card-val">{am}</div></div>
        <div class="card-stat"><div class="card-label">NM</div><div class="card-val">{pm}</div></div>
        <div class="card-stat"><div class="card-label">Ganztags</div><div class="card-val">{full_cnt}</div></div>
        <div class="card-stat"><div class="card-label">Samstag</div><div class="card-val">{sat}</div></div>
      </div>
      {cols_html}
      <div class="card-section">
        <div class="card-section-label">Schichtmuster</div>
        <table class="pattern-table stats card-pattern">
          <thead><tr>{"".join(head_cells)}</tr></thead>
          <tbody><tr>{"".join(pat_cells)}</tr></tbody>
        </table>
      </div>
      <div class="card-section">
        <div class="card-section-label">Nächste gemeinsame Dienste</div>
        <div class="card-line">{escape(upcoming_str)}</div>
      </div>
      <div class="card-section">
        <div class="card-section-label">Letzte gemeinsame Dienste</div>
        <div class="card-line">{escape(past_str)}</div>
      </div>
      {training_html}
    </div>
    '''


def render_person_modals(all_stats: dict, people: dict, coworkers: Counter,
                         favorites: set[str], upcoming: dict[str, list[str]],
                         cache: dict, my_name: str, my_history: dict,
                         today: date) -> str:
    """Versteckte Personen-Karten am Seitenende."""
    my_shifts_by_date: dict[date, set[str]] = {}
    for sh in my_history["shifts"]:
        d_date = date.fromisoformat(sh["date"])
        if sh["half"] == "FULL":
            my_shifts_by_date.setdefault(d_date, set()).update({"AM", "PM"})
        else:
            my_shifts_by_date.setdefault(d_date, set()).add(sh["half"])

    cards = []
    for label in all_stats.keys():
        if label == my_name:
            continue
        cards.append(render_person_card(label, all_stats, people, coworkers,
                                        favorites, upcoming, my_shifts_by_date,
                                        cache, my_name, today))
    return '<div id="person-cards-store" style="display:none">' + "".join(cards) + '</div>'


ROLECALL_COLS = ["DEU-A-Seniorassistent", "DEU-B", "DEU-C", "DEU-D", "DEU-E", "DEU-F", "DEU-G",
                 "Training 1", "Training 2"]


def _rc_role(col: str) -> tuple[str, str, str]:
    """Gibt (emoji, css-klasse, kurzname) für eine Rolecall-Spalte zurück."""
    if col == "DEU-A-Seniorassistent":
        return "🎓", "rc-role-senior", "Senior"
    if col in ("DEU-B","DEU-C","DEU-D","DEU-E","DEU-F","DEU-G"):
        return "🔵", "rc-role-deu", col
    if col in ("Training 1","Training 2"):
        return "🌱", "rc-role-training", col
    return "⚪", "", col


def rolecall_content_html(d: dict, d_date: date, hk: str, people: dict,
                          my_name: str) -> str:
    """Gibt den HTML-Inhalt einer Rolecall-Liste für einen Tag+Halbtag zurück."""
    half_label_map = {"AM": "Vormittag (07:45–13:45)", "PM": "Nachmittag (13:45–20:30)",
                      "FULL": "Ganztags", "SAT": "Samstag (10:00–16:00)"}
    weekday_de = ["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"]

    ents = [e for e in d["entries"]
            if e["column"] in ROLECALL_COLS and e["person"]
            and (e["half"] == hk or e["half"] == "FULL")]
    ents_sorted = sorted(ents, key=lambda e: ROLECALL_COLS.index(e["column"])
                         if e["column"] in ROLECALL_COLS else 99)
    if not ents_sorted:
        return '<p class="muted">Keine Einträge.</p>'

    total = len(ents_sorted)
    rows = []
    for i, e in enumerate(ents_sorted):
        disp = display_name_for(e, people)
        is_me = e["person"] == my_name
        emoji, role_cls, short = _rc_role(e["column"])
        name_display = escape(disp)
        rows.append(
            f'<label class="rc-row {role_cls}">'
            f'<input type="checkbox" class="rc-checkbox">'
            f'<span class="rc-emoji">{emoji}</span>'
            f'<span class="rc-name">{name_display}</span>'
            f'<span class="rc-col">{escape(e["column"])}</span>'
            f'</label>'
        )

    wd = weekday_de[d["weekday"]]
    half_lbl = half_label_map.get(hk, hk)
    counter_id = f"rc-counter-{d_date.isoformat()}-{hk}"
    return (
        f'<div class="rc-modal-inner" data-total="{total}">'
        f'<div class="rc-modal-date">{wd}, {d_date.day}.{d_date.month}.{d_date.year}</div>'
        f'<div class="rc-modal-shift">{half_lbl}</div>'
        f'<div class="rc-counter">'
        f'<span class="rc-missing">{total} fehlen</span> · '
        f'<span class="rc-present">0 anwesend</span>'
        f'</div>'
        f'<div class="rc-list">{"".join(rows)}</div>'
        f'</div>'
    )


def render_rolecall(cache: dict, people: dict, my_name: str, today: date) -> str:
    """Rolecall-Daten: versteckte divs für Modal-Nutzung + Top-Buttons."""
    weekday_de = ["Mo","Di","Mi","Do","Fr","Sa","So"]

    # Alle heutigen + zukünftigen Tage wo ich drin bin
    my_shifts: list[tuple[date, str, str]] = []  # (date, half, display_half)
    half_short_map = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}
    for key in sorted(cache["days"].keys()):
        d_date = date.fromisoformat(key)
        if d_date < today:
            continue
        d = cache["days"][key]
        for e in d["entries"]:
            if e["person"] != my_name:
                continue
            halves = (["AM", "PM"] if e["half"] == "FULL"
                      else ["SAT"] if e["half"] == "SAT"
                      else [e["half"]])
            for h in halves:
                my_shifts.append((d_date, h, key))

    # Hidden divs + Button-Liste
    hidden_divs = []
    buttons_html = []

    for d_date, hk, key in my_shifts:
        d = cache["days"][key]
        rc_id = f"rc-{key.replace('-','')}-{hk}"
        content = rolecall_content_html(d, d_date, hk, people, my_name)
        wd = weekday_de[d_date.weekday()]
        half_short = half_short_map.get(hk, hk)
        label = f"Rolecall {d_date.day}.{d_date.month}. {half_short}"
        title = f"Rolecall – {wd} {d_date.day}.{d_date.month}.{d_date.year} {half_short}"

        hidden_divs.append(
            f'<div id="{rc_id}" class="rolecall-data" '
            f'data-title="{escape(title)}" style="display:none">'
            f'{content}</div>'
        )
        buttons_html.append(
            f'<button class="btn-rolecall" '
            f'onclick="openRolecall(\'{rc_id}\')">{escape(label)}</button>'
        )

    # Alle zukünftigen DEU-Tage: hidden divs für Day-Modal-Buttons
    all_deu_divs = []
    for key in sorted(cache["days"].keys()):
        d_date = date.fromisoformat(key)
        if d_date < today:
            continue
        d = cache["days"][key]
        day_id = key.replace("-", "")
        for hk in (["AM", "PM"] if not d["is_saturday"] else ["SAT"]):
            has_deu = any(e["column"] in ROLECALL_COLS for e in d["entries"]
                          if e["half"] == hk or e["half"] == "FULL")
            if not has_deu:
                continue
            rc_id = f"rc-{day_id}-{hk}"
            # Nur generieren falls noch nicht als "mein Dienst" drin
            if not any(rc_id == f"rc-{key.replace('-','')}-{h}" for _, h, k in my_shifts if k == key):
                content = rolecall_content_html(d, d_date, hk, people, my_name)
                half_short = half_short_map.get(hk, hk)
                weekday_de2 = ["Mo","Di","Mi","Do","Fr","Sa","So"]
                title = f"Rolecall – {weekday_de2[d_date.weekday()]} {d_date.day}.{d_date.month}.{d_date.year} {half_short}"
                all_deu_divs.append(
                    f'<div id="{rc_id}" class="rolecall-data" '
                    f'data-title="{escape(title)}" style="display:none">'
                    f'{content}</div>'
                )

    if not buttons_html and not all_deu_divs:
        return '<div id="rolecall-store" style="display:none"></div>'

    all_hidden = "".join(hidden_divs) + "".join(all_deu_divs)
    topbar = (
        f'<div class="rc-topbar"><span class="rc-topbar-label">Meine Rolecalls:</span>'
        f'{"".join(buttons_html)}</div>'
        if buttons_html else ''
    )
    return f'<div id="rolecall-store" style="display:none">{all_hidden}</div>{topbar}'


def render_int_overview(cache: dict, my_history: dict, people: dict,
                        favorites: set[str], today: date) -> str:
    """Übersicht INT-Desk + DEU-A Senior — nur Bekannte hervorheben."""
    coworkers = my_history["coworkers"]
    my_name = my_history["my_name"]
    rows_future = []
    for key in sorted(cache["days"]):
        d = cache["days"][key]
        d_date = date.fromisoformat(key)
        if d_date < today:
            continue
        cells = []
        for col in ("DEU-A-Seniorassistent", "INT-A-Seniorassistent", "INT-B"):
            ents = [e for e in d["entries"] if e["column"] == col]
            if not ents:
                cells.append('<td class="empty">—</td>')
                continue
            parts = []
            for e in ents:
                disp = display_name_for(e, people)
                badges = person_badges(e["person"], favorites)
                half_short = {"AM": "VM", "PM": "NM", "FULL": "GT", "SAT": "Sa"}
                half_lbl = half_short.get(e["half"], "")
                half_prefix = f'<span class="half-prefix">{half_lbl}</span> ' if half_lbl else ''
                pid = _pid_for(e["person"]) if e["person"] != my_name else ""
                pid_attr = f' data-pid="{pid}"' if pid else ''
                if e["person"] == my_name:
                    parts.append(f'{half_prefix}<span class="me">DU</span>')
                elif coworkers.get(e["person"], 0) > 0:
                    parts.append(f'{half_prefix}<span class="known-name person-link"{pid_attr} title="{coworkers[e["person"]]}× mit mir">{escape(disp)}{badges}</span>')
                else:
                    parts.append(f'{half_prefix}<span class="muted person-link"{pid_attr}>{escape(disp)}{badges}</span>')
            cells.append('<td>' + ' / '.join(parts) + '</td>')
        rows_future.append(f'<tr><td>{key} ({"MoDiMiDoFrSaSo"[d["weekday"]*2:d["weekday"]*2+2]})</td>' + "".join(cells) + '</tr>')

    return f'''
    <h2>INT-Desk + Senior — kommende Tage</h2>
    <p class="muted">Bekannte Namen <span class="known-name">gelb</span>, sonst grau.</p>
    <table class="stats wide">
      <thead><tr><th>Tag</th><th>DEU-A Senior</th><th>INT-A Senior</th><th>INT-B</th></tr></thead>
      <tbody>{"".join(rows_future) or '<tr><td colspan=4>—</td></tr>'}</tbody>
    </table>
    '''


CSS = """
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
       max-width: 1400px; margin: 1em auto; padding: 0 1em; color: #222; }
h1 { margin-bottom: 0.2em; } h2 { margin-top: 1.5em; border-bottom: 2px solid #ddd; padding-bottom: 0.2em; }
.muted { color: #888; font-size: 0.9em; }
.legend { background: #f5f5f5; padding: 0.6em 1em; border-radius: 6px; font-size: 0.9em; margin: 0.5em 0 1em; }
.legend code { background: white; padding: 1px 5px; border-radius: 3px; }

table.cal { border-collapse: collapse; width: 100%; table-layout: fixed; margin-bottom: 1em; }
table.cal th { background: #f0f0f0; padding: 4px; font-size: 0.85em; }
table.cal td { border: 1px solid #ddd; vertical-align: top; height: 90px; padding: 3px;
               position: relative; font-size: 0.78em; }
table.cal td.out { background: #fafafa; color: #ccc; }
table.cal td.sun { background: #f7f7f7; }
table.cal td.empty { background: #fff; }
table.cal td.today { box-shadow: inset 0 0 0 3px #2962ff; }
.dn { position: absolute; top: 2px; right: 4px; font-weight: bold; color: #555; }
td.day { cursor: pointer; }
td.day:hover:not(.all-full-deu) { background: #f5faff; }
.half { display: flex; align-items: center; gap: 3px; margin-top: 4px; flex-wrap: wrap;
        font-family: ui-monospace, Menlo, monospace; font-size: 0.95em;
        padding: 2px 4px; border-radius: 3px; width: calc(100% - 8px); box-sizing: border-box; }
.half:first-of-type { margin-top: 18px; }
.half + .half { margin-top: 4px; }
.half.avail-yes { background: #e8f5e9; }
.half.avail-no { background: #fdecea; }
.hl { color: #888; font-weight: bold; min-width: 1.6em; }
.slot { padding: 1px 5px; border-radius: 3px; font-weight: 600; }
.slot.small { font-size: 0.85em; opacity: 0.7; }
.known { background: #ffd54f; color: #5d4037; padding: 1px 4px; border-radius: 3px; font-weight: bold; }
.me { background: #2962ff; color: white; padding: 1px 5px; border-radius: 3px; font-weight: bold; font-size: 0.85em; }

.day-details { display: none; }

/* Modal */
#day-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.5);
             z-index: 1000; display: none; align-items: flex-start; justify-content: center;
             padding: 1em; overflow-y: auto; }
#day-modal.open { display: flex; }
body.modal-open { overflow: hidden; }
#day-modal-content { background: white; border-radius: 10px; max-width: 700px; width: 100%;
                     margin: 2em auto; box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                     max-height: calc(100vh - 4em); display: flex; flex-direction: column; }
#day-modal-header { display: flex; align-items: center; justify-content: space-between;
                    padding: 1em 1.2em; border-bottom: 1px solid #eee; }
#day-modal-title { margin: 0; font-size: 1.2em; }
#day-modal-close { background: none; border: none; font-size: 1.6em; cursor: pointer;
                   color: #888; padding: 0 0.4em; line-height: 1; }
#day-modal-close:hover { color: #222; }
#day-modal-body { padding: 1em 1.2em; overflow-y: auto; }
#day-modal-body .day-details { display: block; }

.modal-overview { display: flex; flex-direction: column; gap: 6px; margin-bottom: 1em;
                  padding-bottom: 1em; border-bottom: 1px dashed #ddd; }
.modal-half-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
                  padding: 6px 8px; border-radius: 5px; background: #f9f9f9; }
.modal-half-row, .modal-team-half { transition: opacity 0.2s; }

/* Filter im Modal folgen denselben Regeln wie im Hauptkalender */
body:not(.show-full):not(.count-training) .modal-half-row.full-deu,
body:not(.show-full):not(.count-training) .modal-half-row.full-all,
body:not(.show-full):not(.count-training) .modal-team-half.full-deu,
body:not(.show-full):not(.count-training) .modal-team-half.full-all { display: none; }

body:not(.show-full).count-training .modal-half-row.full-all,
body:not(.show-full).count-training .modal-team-half.full-all { display: none; }

body:not(.show-full) .modal-half-row.past-not-mine,
body:not(.show-full) .modal-team-half.past-not-mine { display: none; }
.modal-half-name { font-weight: bold; min-width: 5em; color: #444; }
.modal-half-note { color: #666; font-size: 0.9em; margin-left: auto; }

.modal-teams { display: flex; flex-direction: column; gap: 0.8em; }
.modal-team-box { padding: 0.6em 0.8em; border-radius: 6px; }
.modal-team-name { margin: 0 0 0.5em; font-size: 1em; color: #333; }
.modal-team-half { margin-top: 0.5em; }
.modal-team-half:first-of-type { margin-top: 0; }
.modal-half-label { font-size: 0.8em; font-weight: bold; color: #777;
                    text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }
.modal-persons { display: flex; flex-direction: column; gap: 3px; }
.modal-person { display: flex; align-items: center; gap: 8px; padding: 4px 6px;
                background: rgba(255,255,255,0.7); border-radius: 4px; flex-wrap: wrap; }
.modal-person.known { background: #fff8db; }
.modal-person.me-detail { background: #2962ff; color: white; }
.modal-col { font-family: ui-monospace, Menlo, monospace; font-size: 0.78em;
             background: rgba(0,0,0,0.07); color: #333; padding: 2px 6px;
             border-radius: 3px; font-weight: 600; min-width: 4.5em; text-align: center; }
.modal-person.me-detail .modal-col { background: rgba(255,255,255,0.25); color: white; }

/* Standardansicht: Bekannte/Favoriten-Badges ausgeblendet */
body:not(.show-known) .known { display: none; }
body:not(.show-known) .fav-badge { display: none; }
/* Listen: gelbe Rows, Favoriten-Herz ausblenden */
body:not(.show-known) .known-name { background: none; }
body:not(.show-known) tr td .fav-yes,
body:not(.show-known) tr td .fav-no { display: none; }
/* Schichtmuster: tag-co und tag-fav ausblenden */
body:not(.show-known) .tag-co { display: none; }
body:not(.show-known) .tag-fav { display: none; }
/* "Mit wem ich Dienst hatte"-Tabelle + Schichtmuster komplett ausblenden */
body:not(.show-known) .known-section { display: none; }
/* Modal: bekannte Personen nicht hervorheben */
body:not(.show-known) .modal-person.known { background: none; }
body:not(.show-known) .modal-person .known-name { background: none; }
td.person-link:hover { background: #fffbe6; }

.person-card { padding: 0.5em 0; }
.person-link { cursor: pointer; }
.person-link:hover { text-decoration: underline; }
.person-card .card-header { border-bottom: 1px solid #eee; padding-bottom: 0.5em; margin-bottom: 0.8em; }
.fav-yes { color: #e91e63; font-weight: bold; }
.fav-no { color: #999; }
.fav-row { margin-top: 8px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.fav-copy-btn { padding: 4px 10px; border: 1px solid #e91e63; background: white;
                color: #e91e63; border-radius: 4px; cursor: pointer; font-size: 0.85em; }
.fav-copy-btn:hover { background: #fce4ec; }
.fav-copy-btn.copied { background: #e91e63; color: white; }
.fav-hint { font-size: 0.78em; flex-basis: 100%; }

.training-summary { padding: 4px 8px; border-radius: 4px; font-size: 0.9em;
                    margin-bottom: 6px; }
.training-summary.done { background: #e8f5e9; color: #2e7d32; font-weight: 600; }
.training-summary.future { background: #e3f2fd; color: #1565c0; }
.training-summary.open { background: #fff8e1; color: #e65100; }
.training-list { display: flex; flex-direction: column; gap: 3px; }
.training-entry { display: flex; align-items: center; gap: 8px; padding: 3px 6px;
                  border-radius: 3px; font-family: ui-monospace, Menlo, monospace;
                  font-size: 0.85em; }
.training-entry.past { background: #f5f5f5; }
.training-entry.future { background: #e8eaf6; }
.training-date { min-width: 6.5em; color: #555; }
.training-half { min-width: 2em; font-weight: 600; }
.training-col { color: #777; flex: 1; }
.training-count { color: #2962ff; font-weight: bold; min-width: 2.5em; text-align: right; }
.training-done { color: #2e7d32; font-weight: bold; }
.person-card h3 { margin: 0 0 0.2em; font-size: 1.15em; }
.card-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 0.8em; }
.card-stat { background: #f5f5f5; padding: 6px 8px; border-radius: 5px; text-align: center; }
.card-label { font-size: 0.75em; color: #777; text-transform: uppercase; letter-spacing: 0.5px; }
.card-val { font-size: 1.2em; font-weight: bold; color: #2962ff; }
.card-section { margin-top: 0.9em; }
.card-section-label { font-size: 0.8em; font-weight: bold; color: #555;
                      text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
.card-line { font-family: ui-monospace, Menlo, monospace; font-size: 0.9em; color: #1565c0; }
.card-cols { font-family: ui-monospace, Menlo, monospace; font-size: 0.85em;
             padding: 6px; background: #f9f9f9; border-radius: 4px; line-height: 1.7; }
.card-pattern { width: auto !important; }
.card-pattern td.pat-cell { min-width: 1.8em; }

.rc-topbar { display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
             margin: 0.8em 0; padding: 0.6em 0.8em;
             background: #1a237e; border-radius: 8px; }
.rc-topbar-label { color: rgba(255,255,255,0.7); font-size: 0.85em;
                   font-weight: 600; white-space: nowrap; }
.btn-rolecall { padding: 5px 12px; background: white; color: #1a237e;
                border: none; border-radius: 5px; cursor: pointer;
                font-weight: 700; font-size: 0.88em; letter-spacing: 0.3px; }
.btn-rolecall:hover { background: #e8eaf6; }
.btn-rolecall-small { padding: 4px 10px; font-size: 0.82em;
                      background: #1a237e; color: white;
                      border: 1px solid rgba(255,255,255,0.3); border-radius: 4px;
                      cursor: pointer; font-weight: 600; margin: 0 0 8px; }
.btn-rolecall-small:hover { background: #283593; }
.rc-modal-bar { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }

.rc-modal-inner { padding: 4px 0; }
.rc-modal-date { font-size: 1.2em; font-weight: bold; margin-bottom: 2px; }
.rc-modal-shift { color: #666; font-size: 0.9em; margin-bottom: 10px; }

.rc-counter { display: flex; gap: 1.5em; font-size: 1.05em; font-weight: 600;
              padding: 10px 14px; background: #fff3e0; border-radius: 8px;
              margin-bottom: 14px; }
.rc-missing { color: #e65100; }
.rc-present { color: #2e7d32; }
.rc-counter.rc-counter-done { background: #e8f5e9; }
.rc-counter.rc-counter-done .rc-missing { color: #aaa; text-decoration: line-through; }

.rc-list { display: flex; flex-direction: column; gap: 4px; }
.rc-row { display: flex; align-items: center; gap: 10px;
          padding: 8px 10px; border-radius: 7px;
          cursor: pointer; font-size: 0.97em;
          border: 2px solid transparent;
          transition: background 0.12s, border-color 0.12s;
          -webkit-tap-highlight-color: transparent; }
.rc-row:active { filter: brightness(0.95); }
.rc-role-senior  { background: #fff8e1; }
.rc-role-deu     { background: #e8f0fe; }
.rc-role-training { background: #f1f8e9; }
.rc-row:has(.rc-checkbox:checked) { opacity: 0.6;
  background: #e8f5e9 !important; border-color: #81c784; }
.rc-checkbox { width: 22px; height: 22px; cursor: pointer;
               accent-color: #1a237e; flex-shrink: 0; }
.rc-emoji { font-size: 1.1em; flex-shrink: 0; }
.rc-name { flex: 1; font-weight: 500; line-height: 1.3; }
.rc-col { font-family: ui-monospace, Menlo, monospace; font-size: 0.72em;
          color: #aaa; flex-shrink: 0; }

table.stats { border-collapse: collapse; width: 100%; margin-bottom: 1em; }
table.stats th, table.stats td { border: 1px solid #ddd; padding: 5px 8px; text-align: left; font-size: 0.92em; }
table.stats th { background: #f0f0f0; }
table.stats td.num { text-align: right; font-variant-numeric: tabular-nums; }
.badge-fav, .badge-fav-a { color: #e91e63; font-size: 0.9em; margin-left: 2px; }
.badge-fav-b { color: #ad1457; font-size: 0.9em; margin-left: 2px; }
.badge-fav-c { color: #880e4f; font-size: 0.9em; margin-left: 2px; }
.badge-shit { font-size: 0.85em; margin-left: 2px; }
.shit-badge { font-size: 0.85em; }
body:not(.show-known) .badge-fav,
body:not(.show-known) .badge-fav-a,
body:not(.show-known) .badge-fav-b,
body:not(.show-known) .badge-fav-c { display: none; }
.day-notes { position: absolute; top: 2px; left: 2px; font-size: 0.85em;
             line-height: 1; display: flex; gap: 2px; }
.day-note { cursor: default; }

.known-name { background: #ffd54f; padding: 1px 4px; border-radius: 3px; }
.half-prefix { font-family: ui-monospace, Menlo, monospace; font-size: 0.78em;
               color: #666; font-weight: 600; padding: 0 3px; background: #f0f0f0;
               border-radius: 2px; margin-right: 2px; }
               color: #666; font-weight: 600; padding: 0 3px; background: #f0f0f0;
               border-radius: 2px; margin-right: 2px; }
.fav-badge { background: #e91e63; color: white; padding: 1px 5px; border-radius: 3px;
             font-weight: bold; font-size: 0.85em; margin-left: 2px; }

.controls { margin: 1em 0; display: flex; flex-wrap: wrap; gap: 6px; }
.controls button { padding: 4px 10px; cursor: pointer; border: 1px solid #ccc;
                   background: white; border-radius: 4px; font-size: 0.9em; }
.controls button:hover { background: #f5f5f5; }
.btn-reset { border-color: #2962ff !important; color: #2962ff !important; font-weight: 600; }

td.pattern { font-family: ui-monospace, Menlo, monospace; font-size: 0.85em; }
td.upcoming { font-family: ui-monospace, Menlo, monospace; font-size: 0.85em;
              color: #1565c0; white-space: nowrap; }
table.pattern-table th.pat-cell { font-weight: normal; padding: 2px 4px; font-size: 0.8em;
                                  background: #f5f5f5; text-align: center; }
table.pattern-table th.pat-cell small { color: #777; }
table.pattern-table td.pat-cell { text-align: center; padding: 2px 4px; font-variant-numeric: tabular-nums;
                                  font-size: 0.85em; min-width: 1.8em; }
table.pattern-table td.pat-sat, table.pattern-table th.pat-sat { border-left: 2px solid #999; }
table.pattern-table td.pat-name { font-size: 0.9em; }
table.pattern-table td.pat-total { font-weight: bold; }
.tag { display: inline-block; padding: 0 5px; border-radius: 8px; font-size: 0.75em;
       margin-left: 3px; font-weight: bold; }
.tag-co { background: #ffd54f; color: #5d4037; }
.tag-tr { background: #cfe2ff; color: #084298; }
.tag-tr-done { background: #d1e7dd; color: #0a3622; }
.tag-fav { background: #e91e63; color: white; }

table.cal td.holiday { background: repeating-linear-gradient(45deg, #fafafa, #fafafa 6px, #f0f0f0 6px, #f0f0f0 12px); }
.holiday-label { margin-top: 16px; color: #888; font-style: italic; font-size: 0.9em; text-align: center; }

/*
  Filter-Logik (default = "DEU-Slots zählen, Training nicht"):
    - .full-deu wird ausgeblendet (kein DEU frei)
    - "alles voll" Hinweis erscheint wenn alle Halbtage DEU-voll sind

  Mit Body-Klasse .count-training:
    - Trainings-Slots zählen wieder als frei
    - nur .full-all wird ausgeblendet
    - Hinweis nur bei .all-full-all

  Mit Body-Klasse .show-full:
    - alles wird gezeigt, kein Filter
*/
body:not(.show-full):not(.count-training) .half.full-deu,
body:not(.show-full):not(.count-training) .half.full-all { display: none; }
body:not(.show-full):not(.count-training) td.day.all-full-deu .all-full-hint { display: block; }
body:not(.show-full):not(.count-training) td.day.all-full-deu { cursor: default; }

body:not(.show-full).count-training .half.full-all { display: none; }
body:not(.show-full).count-training td.day.all-full-all .all-full-hint { display: block; }
body:not(.show-full).count-training td.day.all-full-all { cursor: default; }
body.count-training td.day.all-full-deu:not(.all-full-all) .all-full-hint { display: none; }

/* Vergangene Halbtage, an denen ich NICHT eingetragen war: im Standard ausblenden */
body:not(.show-full) .half.past-not-mine { display: none; }
body:not(.show-full) td.day.past-not-mine .all-full-hint { display: none; }
body:not(.show-full) td.day.past-not-mine { cursor: default; opacity: 0.5; }

.all-full-hint { display: none; margin-top: 16px; color: #aaa; font-size: 0.85em;
                 font-style: italic; text-align: center; }

/* Stundenfortschritt */
.hours-progress { background: #fafafa; padding: 0.8em 1em; border-radius: 8px;
                  margin: 1em 0; border: 1px solid #e0e0e0; }
.hours-progress h2 { margin-top: 0; border-bottom: none; font-size: 1.3em; }
.prog-block { margin: 0.8em 0; }
.prog-head { font-size: 1.05em; margin-bottom: 4px; }
.prog-num { font-size: 1.4em; font-weight: bold; color: #2962ff; }
.prog-goal { color: #555; }
.prog-pct { color: #2962ff; font-weight: 600; margin: 0 4px; }
.bar { width: 100%; height: 22px; background: #eee; border-radius: 4px; overflow: hidden;
       display: flex; }
.bar-earned { background: #2962ff; height: 100%; }
.bar-planned { background: #90caf9; height: 100%; }
.prog-eta { margin-top: 4px; font-size: 0.92em; }
.eta-done { color: #2e7d32; font-weight: bold; }
.eta-sched { color: #1565c0; }
.eta-extra { color: #6a1b9a; }
.eta-none { color: #999; font-style: italic; }

/* Mobile-Anpassungen */
@media (max-width: 700px) {
  body { margin: 0.5em; padding: 0 0.3em; font-size: 14px; }
  h1 { font-size: 1.4em; }
  h2 { font-size: 1.15em; }
  .legend, .controls { font-size: 0.85em; }
  .controls button { display: block; width: 100%; margin: 4px 0; }

  /* Kalender: Wochenende abhängige Spalten okay, aber dichter */
  table.cal { font-size: 0.7em; }
  table.cal td { height: auto; min-height: 60px; padding: 2px; font-size: 0.78em; }
  table.cal th { font-size: 0.78em; padding: 2px; }
  .dn { font-size: 0.95em; }
  .toggle { width: 16px; height: 16px; font-size: 11px; }
  .half { font-size: 0.78em; gap: 2px; margin-top: 12px; }
  .slot { padding: 0 3px; font-size: 0.95em; }
  .hl { min-width: 1.3em; }
  .known, .fav-badge, .me { font-size: 0.78em; padding: 0 3px; }

  /* Detail-Box */
  .day-details { font-size: 0.78em; }
  .team-row { font-size: 0.85em; }

  /* Tabellen scrollbar */
  table.stats { font-size: 0.8em; display: block; overflow-x: auto; white-space: nowrap; }
  table.stats td, table.stats th { padding: 3px 5px; }
  table.pattern-table td.pat-cell { min-width: 1.5em; padding: 1px 2px; font-size: 0.8em; }

  /* Progress kompakter */
  .hours-progress { padding: 0.5em 0.7em; }
  .prog-num { font-size: 1.2em; }
  .bar { height: 16px; }
}
"""

JS = """
function openDayModal(id) {
  const el = document.getElementById('det-' + id);
  if (!el) return;
  showInModal(el.dataset.title || '', el);
}
function openPersonModal(pid) {
  const el = document.getElementById('card-' + pid);
  if (!el) return;
  showInModal(el.dataset.title || '', el);
}
function showInModal(title, sourceEl) {
  const modal = document.getElementById('day-modal');
  const body = document.getElementById('day-modal-body');
  const titleEl = document.getElementById('day-modal-title');
  titleEl.textContent = title;
  body.innerHTML = '';
  const clone = sourceEl.cloneNode(true);
  clone.style.display = 'block';
  clone.removeAttribute('id');
  body.appendChild(clone);
  modal.classList.add('open');
  document.body.classList.add('modal-open');
  body.scrollTop = 0;
}
function openRolecall(id) {
  const el = document.getElementById(id);
  if (!el) return;
  showInModal(el.dataset.title || 'Rolecall', el);
}
function rcUpdateCount(inner) {
  if (!inner) return;
  const total = parseInt(inner.dataset.total) || 0;
  const checked = inner.querySelectorAll('.rc-checkbox:checked').length;
  const missing = total - checked;
  const missingEl = inner.querySelector('.rc-missing');
  const presentEl = inner.querySelector('.rc-present');
  if (missingEl) missingEl.textContent = missing + ' fehlen';
  if (presentEl) presentEl.textContent = checked + ' anwesend';
  const counter = inner.querySelector('.rc-counter');
  if (counter) counter.classList.toggle('rc-counter-done', missing === 0);
}
document.addEventListener('change', function(e) {
  if (e.target.classList.contains('rc-checkbox')) {
    rcUpdateCount(e.target.closest('.rc-modal-inner'));
  }
});
function closeDayModal() {
  document.getElementById('day-modal').classList.remove('open');
  document.body.classList.remove('modal-open');
}
function copyFav(btn, label) {
  navigator.clipboard.writeText(label).then(function() {
    const orig = btn.textContent;
    btn.textContent = '✓ kopiert: ' + label;
    btn.classList.add('copied');
    setTimeout(function() {
      btn.textContent = orig;
      btn.classList.remove('copied');
    }, 2500);
  }).catch(function() {
    // Fallback: prompt zum manuellen Kopieren
    window.prompt('Diese Zeile in favorites.txt einfügen:', label);
  });
}
function toggleFullShifts() {
  document.body.classList.toggle('show-full');
  const btn = document.getElementById('btn-show-full');
  if (btn) {
    btn.textContent = document.body.classList.contains('show-full')
      ? 'Volle Schichten ausblenden'
      : 'Volle Schichten einblenden';
  }
}
function toggleCountTraining() {
  document.body.classList.toggle('count-training');
  const btn = document.getElementById('btn-count-training');
  if (btn) {
    btn.textContent = document.body.classList.contains('count-training')
      ? 'Trainings-Slots NICHT zählen'
      : 'Trainings-Slots auch als frei zählen';
  }
}
function toggleShowKnown() {
  document.body.classList.toggle('show-known');
  const btn = document.getElementById('btn-show-known');
  if (btn) {
    btn.textContent = document.body.classList.contains('show-known')
      ? 'Bekannte ausblenden'
      : 'Bekannte & Favoriten anzeigen';
  }
}
function resetView() {
  document.body.classList.remove('show-full','show-known','count-training');
  document.getElementById('btn-show-full').textContent = 'Volle Schichten einblenden';
  document.getElementById('btn-count-training').textContent = 'Trainings-Slots auch als frei zählen';
  const bsk = document.getElementById('btn-show-known');
  if (bsk) bsk.textContent = 'Bekannte & Favoriten anzeigen';
}
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeDayModal();
});
document.addEventListener('click', function(e) {
  // Personen-Link hat Priorität (auch wenn innerhalb td.day oder Modal)
  const personEl = e.target.closest('[data-pid]');
  if (personEl) {
    e.stopPropagation();
    openPersonModal(personEl.dataset.pid);
    return;
  }
  const td = e.target.closest('td.day');
  if (td && !e.target.closest('#day-modal')) {
    const body = document.body;
    const showFull = body.classList.contains('show-full');
    const countTraining = body.classList.contains('count-training');
    if (!showFull) {
      if (td.classList.contains('past-not-mine')) return;
      if (countTraining && td.classList.contains('all-full-all')) return;
      if (!countTraining && td.classList.contains('all-full-deu')) return;
    }
    const id = td.dataset.dayId;
    if (id) openDayModal(id);
    return;
  }
  if (e.target.id === 'day-modal') closeDayModal();
});
"""


def compute_hours_progress(cache: dict, my_name: str, today: date,
                           now_time: "time | None" = None) -> dict:
    """
    Aggregiert Stunden aus eigenen Diensten, getrennt pro Ziel.

    Heutige Dienste werden je nach Uhrzeit als bereits 'earned' gezählt:
    - AM-Dienst gilt als absolviert ab 13:45 (Ende des VM-Diensts)
    - PM-Dienst gilt als absolviert ab 20:00
    - FULL gilt als absolviert ab 20:00 (Ende NM)
    - SAT gilt als absolviert ab 16:00
    """
    from datetime import time as dt_time
    if now_time is None:
        now_time = dt_time(0, 0)

    AM_DONE = dt_time(13, 45)
    PM_DONE = dt_time(20, 0)
    SAT_DONE = dt_time(16, 0)

    def shift_finished(d_date: date, half: str) -> bool:
        if d_date < today:
            return True
        if d_date > today:
            return False
        # heute
        if half == "AM":
            return now_time >= AM_DONE
        if half == "PM" or half == "FULL":
            return now_time >= PM_DONE
        if half == "SAT":
            return now_time >= SAT_DONE
        return False

    all_events: list[tuple[date, float, str, bool]] = []

    for key, d in cache["days"].items():
        d_date = date.fromisoformat(key)
        for e in d["entries"]:
            if e["person"] != my_name:
                continue
            if e["half"] == "FULL":
                h = HOURS_PER_FULL
            elif e["half"] == "SAT":
                h = HOURS_PER_SAT
            else:
                h = HOURS_PER_HALF
            label = f'{e["column"]} {e["half"]}'
            all_events.append((d_date, h, label, shift_finished(d_date, e["half"])))

    for ex in EXTRA_HOURS:
        d_date = date.fromisoformat(ex["date"])
        # Extras gelten als komplett absolviert sobald das Datum erreicht ist
        is_earned = d_date < today or d_date == today
        all_events.append((d_date, ex["hours"], ex["label"], is_earned))

    def aggregate(count_from: date, goal: float,
                  borrow_rate_from: dict | None = None) -> dict:
        """
        Stunden-Aggregation mit Zählung erst ab count_from.

        Wenn borrow_rate_from gesetzt ist und today < count_from: wir haben
        noch keine eigene Rate, also leihen wir die "earned"-Rate vom anderen
        Ziel (typisch: Fachspezifikum übernimmt Master-Rate vor 2.7.).
        """
        earned = 0.0
        planned = 0.0
        planned_dates: list[tuple[date, float]] = []
        for d_date, h, _label, is_past in all_events:
            if d_date < count_from:
                continue
            if is_past:
                earned += h
            else:
                planned += h
                planned_dates.append((d_date, h))

        # Eigene Rate (nur erarbeitet ab count_from)
        if today >= count_from:
            weeks_e = max((today - count_from).days / 7.0, 1/7)
            rate_earned = earned / weeks_e
        else:
            weeks_e = 0.0
            rate_earned = 0.0

        # Wenn Zielzählung in der Zukunft liegt, nutze die aktuelle Master-Rate
        rate_for_extrapolation = rate_earned
        if today < count_from and borrow_rate_from is not None:
            rate_for_extrapolation = borrow_rate_from["rate_earned"]

        # Rate inkl. geplant
        if planned_dates:
            last_planned = max(d for d, _ in planned_dates)
            weeks_t = max((last_planned - count_from).days / 7.0, 1/7)
            rate_with_planned = (earned + planned) / weeks_t
        else:
            rate_with_planned = rate_for_extrapolation

        def eta(rate: float, use_planned: bool) -> dict:
            """ETA-Berechnung. use_planned: ob die geplanten Dienste vom Goal abgezogen werden."""
            if today >= count_from and earned >= goal:
                return {"date": None, "method": "done"}
            # Versuch: reichen geplante Dienste schon?
            if use_planned:
                cumulative = earned
                for d_iso, h in sorted(planned_dates):
                    cumulative += h
                    if cumulative >= goal:
                        return {"date": d_iso.isoformat(), "method": "scheduled"}
            if rate <= 0:
                return {"date": None, "method": "no_rate"}
            # Anker: heute, ODER count_from (wenn in Zukunft), ODER letzter geplanter Dienst
            anchor = max(today, count_from)
            if use_planned and planned_dates:
                last_planned = max(d for d, _ in planned_dates)
                anchor = max(anchor, last_planned)
            already = earned + (planned if use_planned else 0.0)
            remaining = goal - already
            if remaining <= 0:
                return {"date": anchor.isoformat(), "method": "extrapolated"}
            weeks_needed = remaining / rate
            eta_date = anchor + timedelta(days=int(round(weeks_needed * 7)))
            return {"date": eta_date.isoformat(), "method": "extrapolated"}

        return {
            "earned": earned, "planned": planned,
            "rate_earned": rate_earned,
            "rate_for_extrapolation": rate_for_extrapolation,
            "rate_with_planned": rate_with_planned,
            "eta_earned": eta(rate_for_extrapolation, use_planned=False),
            "eta_planned": eta(rate_with_planned, use_planned=True),
            "count_from": count_from.isoformat(),
            "uses_borrowed_rate": today < count_from and borrow_rate_from is not None,
        }

    psy_result = aggregate(PROGRESS_START, GOAL_PSYCHOLOGY)
    pt_result = aggregate(PT_COUNT_START, GOAL_PSYCHOTHERAPY,
                          borrow_rate_from=psy_result)
    return {"psy": psy_result, "pt": pt_result}


def render_hours_progress(prog: dict) -> str:
    psy = prog["psy"]
    pt = prog["pt"]

    def eta_text(eta: dict, prefix: str) -> str:
        m = eta["method"]
        if m == "done":
            return f'<span class="eta-done">{prefix}: ✓ erreicht</span>'
        if m == "scheduled":
            return f'<span class="eta-sched">{prefix}: <b>{eta["date"]}</b> (mit geplanten Diensten)</span>'
        if m == "extrapolated":
            return f'<span class="eta-extra">{prefix}: ca. <b>{eta["date"]}</b></span>'
        return f'<span class="eta-none">{prefix}: noch keine Rate</span>'

    def bar(name: str, goal: float, agg: dict) -> str:
        earned = agg["earned"]
        planned = agg["planned"]
        rate_e = agg["rate_for_extrapolation"]
        rate_p = agg["rate_with_planned"]
        earned_pct = min(earned / goal * 100, 100)
        total_pct = min((earned + planned) / goal * 100, 100)
        planned_pct = max(total_pct - earned_pct, 0)
        remaining = max(goal - earned - planned, 0)
        count_from_note = ""
        if agg["count_from"] != PROGRESS_START.isoformat():
            count_from_note = f' <span class="muted">(zählt ab {agg["count_from"]})</span>'
        rate_label_e = f"bei aktuellem Tempo ({rate_e:.1f} h/W)"
        if agg["uses_borrowed_rate"]:
            rate_label_e = f"bei aktuellem Master-Tempo ({rate_e:.1f} h/W ab {agg['count_from']})"
        return f'''
        <div class="prog-block">
          <div class="prog-head"><b>{name}</b>{count_from_note}:
               <span class="prog-num">{earned:.1f}</span> /
               <span class="prog-goal">{goal:.0f}</span> h
               <span class="prog-pct">({earned/goal*100:.0f}% erarbeitet, {(earned+planned)/goal*100:.0f}% gesamt)</span>
               <span class="muted">+{planned:.1f} geplant · {remaining:.1f} fehlen</span></div>
          <div class="bar">
            <div class="bar-earned" style="width:{earned_pct:.1f}%"
                 title="erarbeitet {earned:.1f}h ({earned/goal*100:.0f}%)"></div>
            <div class="bar-planned" style="width:{planned_pct:.1f}%"
                 title="geplant {planned:.1f}h"></div>
          </div>
          <div class="prog-eta">
            {eta_text(agg["eta_earned"], rate_label_e)}<br>
            {eta_text(agg["eta_planned"], f"inkl. geplante Dienste ({rate_p:.1f} h/W)")}
          </div>
        </div>'''

    return f'''
    <section class="hours-progress">
      <h2>Stundenfortschritt</h2>
      {bar(LABEL_PSY, GOAL_PSYCHOLOGY, psy)}
      {bar(LABEL_PT, GOAL_PSYCHOTHERAPY, pt)}
      <p class="muted">Halbtag = {HOURS_PER_HALF} h · Ganztags = {HOURS_PER_FULL} h · Samstag = {HOURS_PER_SAT} h.
      Masterpraktikum zählt ab {PROGRESS_START.isoformat()}, Fachspezifikum ab {PT_COUNT_START.isoformat()} (nach Propädeutikum-Abschluss).</p>
    </section>
    '''


def build_report() -> Path:
    global _SHITLIST, _FRIENDS
    cache = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    people = load_people()
    favorites = load_favorites()
    shitlist = load_shitlist()
    friends = load_friends()
    notes = load_notes()
    _SHITLIST = shitlist
    _FRIENDS = friends
    availability = load_availability()
    today = date.today()
    from datetime import datetime as _dt
    now_time = _dt.now().time()
    my_history = reconstruct_my_history(cache, today, now_time)
    training_done = my_history["training_count"] >= TRAINING_QUOTA
    all_stats = people_stats_in_cache(cache)
    upcoming, next_shared_date = upcoming_shared_shifts(cache, my_history["my_name"], today)
    progress = compute_hours_progress(cache, my_history["my_name"], today, now_time)

    summaries: dict[str, dict] = {}
    for key, d in cache["days"].items():
        summaries[key] = compute_day_summary(d, my_history, favorites, shitlist, notes)
    raw_days = cache["days"]

    cur_y, cur_m = today.year, today.month
    nxt_m = cur_m + 1; nxt_y = cur_y
    if nxt_m > 12:
        nxt_m -= 12; nxt_y += 1

    rolecall_html = render_rolecall(cache, people, my_history["my_name"], today)

    parts = [f"""<!doctype html><html lang="de"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ambulanzkalender Übersicht</title>
<style>{CSS}</style></head><body>
<script>{JS}</script>
<h1>Ambulanzkalender — Übersicht</h1>
<p class="muted">Stand: {today.isoformat()} · Ich: <b>{my_history['my_name']}</b>
   · Trainings: <b>{my_history['training_count']}/{TRAINING_QUOTA}</b>
   · Favoriten: <b>{len(favorites)}</b> ♥
   {'<span class="known">Training abgeschlossen ✓</span>' if training_done else ''}
</p>

<div class="legend">
  <b>Lesehilfe:</b>
  <code>VM</code>=Vormittag, <code>NM</code>=Nachmittag.
  <code>D x/6</code> = besetzte/insgesamt DEU-Slots.
  <code>T x/2</code> = besetzte/insgesamt Training-Slots.
  Farbe der Boxen: <span class="slot" style="background:hsl(120,65%,75%)">leer</span> →
  <span class="slot" style="background:hsl(60,65%,75%)">mittel</span> →
  <span class="slot" style="background:hsl(0,65%,75%)">voll</span>.
  <span class="known">★ N</span> = N Bekannte anwesend.
  <span class="fav-badge">♥</span> = Favorit anwesend.
  Klick auf Tag öffnet Detail-Popup.
  {'<b>→ Trainings priorisiert (T zuerst)</b>' if not training_done else '<b>→ Reguläre Slots priorisiert</b>'}
</div>

<div class="controls">
  <button id="btn-count-training" onclick="toggleCountTraining()">Trainings-Slots auch als frei zählen</button>
  <button id="btn-show-full" onclick="toggleFullShifts()">Volle Schichten einblenden</button>
  <button id="btn-show-known" onclick="toggleShowKnown()">Bekannte &amp; Favoriten anzeigen</button>
  <button onclick="resetView()" class="btn-reset">↺ Standardansicht</button>
</div>

{rolecall_html}
<div id="day-modal" role="dialog" aria-modal="true">
  <div id="day-modal-content">
    <div id="day-modal-header">
      <h3 id="day-modal-title"></h3>
      <button id="day-modal-close" onclick="closeDayModal()" aria-label="Schließen">×</button>
    </div>
    <div id="day-modal-body"></div>
  </div>
</div>
"""]

    parts.append(render_hours_progress(progress))
    parts.append(render_month(cur_y, cur_m, summaries, raw_days, training_done,
                              today, my_history, all_stats, people, favorites, availability))
    parts.append(render_month(nxt_y, nxt_m, summaries, raw_days, training_done,
                              today, my_history, all_stats, people, favorites, availability))
    parts.append(render_people_stats(my_history, all_stats, people, favorites,
                                     upcoming, next_shared_date))
    parts.append(render_shift_patterns(cache, all_stats, my_history, people,
                                       favorites, next_shared_date, today))
    parts.append(render_int_overview(cache, my_history, people, favorites, today))
    parts.append(render_person_modals(all_stats, people, my_history["coworkers"],
                                      favorites, upcoming, cache,
                                      my_history["my_name"], my_history, today))
    parts.append("</body></html>")

    OUT_FILE.write_text("\n".join(parts), encoding="utf-8")
    return OUT_FILE


if __name__ == "__main__":
    p = build_report()
    print(f"Report geschrieben: {p}")
